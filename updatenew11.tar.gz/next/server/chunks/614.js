"use strict";
exports.id = 614;
exports.ids = [614];
exports.modules = {

/***/ 180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function IwsLink(props) {
    const { href , className , children , onClick , target , rel  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: href,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: className,
            onClick: (e)=>{
                if (onClick) {
                    onClick();
                }
            },
            target: target,
            rel: rel,
            children: children
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IwsLink);


/***/ }),

/***/ 5295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _IwsLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(180);
"use client";



function Footer() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "border-t bg-[#F9F9F9]",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col sm:flex-row justify-between items-center border-b pb-8",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4 mb-4 sm:mb-0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/canopy.svg",
                                    alt: "Canopy Wave Logo",
                                    width: 48,
                                    height: 48
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-bold text-gray-600",
                                    children: "Canopy Wave"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            href: "/contact",
                            className: "px-4 py-2 border border-gray-300 rounded-md text-sm hover:bg-gray-50 mb-4 sm:mb-0",
                            children: "Contact us"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col lg:flex-row justify-between items-start mb-12 pt-8",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-8 w-full lg:w-auto",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-semibold mb-4",
                                        children: "Products"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "space-y-2 text-sm",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/compute-services",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Compute Services"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/storage-services",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Storage Services"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/networking-services",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Networking Services"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/platform",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Platform"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-semibold mb-4",
                                        children: "Solutions"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "space-y-2 text-sm",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/model-training",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Model Training"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/inference",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Inference"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/rendering",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Rendering"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/private-cloud",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Private cloud and GPUs deployment"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/networking-hardware",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Networking Hardware Solution"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-semibold mb-4",
                                        children: "Pricing"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "space-y-2 text-sm",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/pricing/h100",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "NVIDIA SXM5 H100"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/pricing/h200",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "NVIDIA SXM5 H200"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/pricing/cpu",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Network Shared Storage"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/pricing/cloud-storage",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Object Storage"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/pricing/rdma",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Additional public IP address"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-semibold mb-4",
                                        children: "Data Center"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "space-y-2 text-sm",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/iceland",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Iceland 1"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/iceland",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Iceland 2"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-semibold mb-4",
                                        children: "Resources"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "space-y-2 text-sm",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/cloud-api",
                                                className: "text-gray-500 hover:text-gray-700",
                                                children: "Manage Cloud Via API"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "font-semibold mb-4",
                                        children: "About"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "space-y-2 text-sm",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/about",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "About US"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/about/careers",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Careers"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/about/newsroom",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Newsroom"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    href: "/blog",
                                                    className: "text-gray-500 hover:text-gray-700",
                                                    children: "Blog"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "border-t w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col sm:flex-row justify-between items-center pt-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-sm text-gray-500 mb-4 sm:mb-0",
                            children: "\xa9 2025 All rights reserved."
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 1199:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _IwsLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(180);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3972);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4685);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_6__]);
_components_ui_button__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";







function Header() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const currentRouter = _router__WEBPACK_IMPORTED_MODULE_4__/* .router.find */ .N.find((e)=>e.path === router.asPath)?.name;
    const { 0: showProducts , 1: setShowProducts  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showSolutions , 1: setShowSolutions  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showPricing , 1: setShowPricing  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showDataCenter , 1: setShowDataCenter  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showResources , 1: setShowResources  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showAbout , 1: setShowAbout  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobileProducts , 1: setShowMobileProducts  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobileSolutions , 1: setShowMobileSolutions  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobilePricing , 1: setShowMobilePricing  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobileDataCenter , 1: setShowMobileDataCenter  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobileResources , 1: setShowMobileResources  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobileAbout , 1: setShowMobileAbout  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showMobileSubMenu , 1: setShowMobileSubMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(null);
    const menuRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const solutionsRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const pricingRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const datacenterRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const resourcesRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const aboutRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setShowProducts(false);
            }
            if (solutionsRef.current && !solutionsRef.current.contains(event.target)) {
                setShowSolutions(false);
            }
            if (pricingRef.current && !pricingRef.current.contains(event.target)) {
                setShowPricing(false);
            }
            if (datacenterRef.current && !datacenterRef.current.contains(event.target)) {
                setShowDataCenter(false);
            }
            if (resourcesRef.current && !resourcesRef.current.contains(event.target)) {
                setShowResources(false);
            }
            if (aboutRef.current && !aboutRef.current.contains(event.target)) {
                setShowAbout(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
        className: "bg-[#F9F9F9] border-y-2 border-gray-200 fixed top-0 left-0 right-0 z-50 py-2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between h-16",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-shrink-0 flex items-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    href: "/",
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: "/canopy.svg",
                                            alt: "Canopy Wave Logo",
                                            width: 50,
                                            height: 50,
                                            priority: true
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-l font-bold text-gray-600 ml-2",
                                            children: "Canopy Wave"
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "hidden md:flex flex-1 justify-between items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex-1"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center space-x-8 h-16",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative",
                                            ref: menuRef,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "text-gray-600 text-sm font-medium hover:text-gray-900 flex items-center",
                                                    onClick: ()=>setShowProducts(!showProducts),
                                                    children: [
                                                        "Products",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showProducts ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                showProducts && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-[#F9F9F9] bg-opacity-90 absolute -left-8 py-6 mt-2 shadow-lg border-t border-gray-100 z-50 min-w-[560px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "grid grid-cols-6 gap-8",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "col-span-3",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "font-semibold mb-4",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                href: "/compute-services",
                                                                                className: "text-gray-900 hover:text-[#8CC63F] flex items-center",
                                                                                children: [
                                                                                    "Compute Services",
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                        className: "w-4 h-4 ml-1",
                                                                                        fill: "none",
                                                                                        stroke: "currentColor",
                                                                                        viewBox: "0 0 24 24",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                            strokeLinecap: "round",
                                                                                            strokeLinejoin: "round",
                                                                                            strokeWidth: 2,
                                                                                            d: "M19 9l-7 7-7-7"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "space-y-2 text-sm",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                                href: "/compute-services#gpu-cloud",
                                                                                                className: "text-gray-600 hover:text-gray-900 flex items-center whitespace-nowrap",
                                                                                                children: [
                                                                                                    "GPU Cloud on-demand Cluster",
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                                        className: "w-4 h-4 ml-1",
                                                                                                        fill: "none",
                                                                                                        stroke: "currentColor",
                                                                                                        viewBox: "0 0 24 24",
                                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                                            strokeLinecap: "round",
                                                                                                            strokeLinejoin: "round",
                                                                                                            strokeWidth: 2,
                                                                                                            d: "M19 9l-7 7-7-7"
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                                                className: "pl-4 mt-2 space-y-2",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                                            href: "/compute-services#hgx-h200",
                                                                                                            className: "text-gray-600 hover:text-gray-900",
                                                                                                            onClick: ()=>setShowProducts(false),
                                                                                                            children: "NVIDIA HGX H200"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                                            href: "/compute-services#hgx-h100",
                                                                                                            className: "text-gray-600 hover:text-gray-900",
                                                                                                            onClick: ()=>setShowProducts(false),
                                                                                                            children: "NVIDIA HGX H100"
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/compute-services#cpu-node",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "CPU Nodes"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/compute-services#bare-metal",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "Bare Metal GPU Cluster"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "col-span-3",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "font-semibold mb-4",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                href: "/storage-services",
                                                                                className: "flex items-center text-gray-900 hover:text-[#8CC63F]",
                                                                                children: [
                                                                                    "Storage Services",
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                        className: "w-4 h-4 ml-1",
                                                                                        fill: "none",
                                                                                        stroke: "currentColor",
                                                                                        viewBox: "0 0 24 24",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                            strokeLinecap: "round",
                                                                                            strokeLinejoin: "round",
                                                                                            strokeWidth: 2,
                                                                                            d: "M19 9l-7 7-7-7"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "space-y-2 text-sm",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/storage-services#local-storage",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "Local Storage"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/storage-services#shared-storage",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "Shared Storage"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/storage-services#object-storage",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "Object Storage"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "col-span-3",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "font-semibold mb-4",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                href: "/networking-services",
                                                                                className: "flex items-center text-gray-900 hover:text-[#8CC63F]",
                                                                                children: [
                                                                                    "Networking Services",
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                        className: "w-4 h-4 ml-1",
                                                                                        fill: "none",
                                                                                        stroke: "currentColor",
                                                                                        viewBox: "0 0 24 24",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                            strokeLinecap: "round",
                                                                                            strokeLinejoin: "round",
                                                                                            strokeWidth: 2,
                                                                                            d: "M19 9l-7 7-7-7"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "space-y-2 text-sm",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/networking-services#infiniband-networking",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "InfiniBand Networking"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/networking-services#private-cloud",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "RoceV2 Networking"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "col-span-3",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "font-semibold mb-4",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                href: "/platform",
                                                                                className: "flex items-center text-gray-900 hover:text-[#8CC63F]",
                                                                                children: [
                                                                                    "Platform",
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                        className: "w-4 h-4 ml-1",
                                                                                        fill: "none",
                                                                                        stroke: "currentColor",
                                                                                        viewBox: "0 0 24 24",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                            strokeLinecap: "round",
                                                                                            strokeLinejoin: "round",
                                                                                            strokeWidth: 2,
                                                                                            d: "M19 9l-7 7-7-7"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "space-y-2 text-sm",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/platform#dcim-platform",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "Canopy DCIM Platform"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/platform#cloud-platform",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>setShowProducts(false),
                                                                                        children: "Wave GPU cloud platform"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative",
                                            ref: solutionsRef,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "text-gray-600 text-sm font-medium hover:text-gray-900 flex items-center",
                                                    onClick: ()=>setShowSolutions(!showSolutions),
                                                    children: [
                                                        "Solutions",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showSolutions ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                showSolutions && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-[#F9F9F9] bg-opacity-90 absolute -left-8 py-6 mt-2 shadow-lg border-t border-gray-100 z-50 min-w-[300px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                            className: "space-y-2 text-sm",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/model-training",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowSolutions(false);
                                                                        },
                                                                        children: "Model Training"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/inference",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowSolutions(false);
                                                                        },
                                                                        children: "Inference"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/rendering",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowSolutions(false);
                                                                        },
                                                                        children: "Rendering"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/private-cloud",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowSolutions(false);
                                                                        },
                                                                        children: "Private Cloud and GPUs Deployment"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/networking-hardware",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowSolutions(false);
                                                                        },
                                                                        children: "Networking Hardware Solution"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative",
                                            ref: pricingRef,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "text-gray-600 text-sm font-medium hover:text-gray-900 flex items-center",
                                                    onClick: ()=>setShowPricing(!showPricing),
                                                    children: [
                                                        "Pricing",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showPricing ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                showPricing && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-[#F9F9F9] bg-opacity-90 absolute -left-8 py-6 mt-2 shadow-lg border-t border-gray-100 z-50 min-w-[280px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                            className: "space-y-2 text-sm",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/pricing#H100",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowPricing(false);
                                                                        },
                                                                        children: "NVIDIA SXM5 H100"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/pricing#H200",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowPricing(false);
                                                                        },
                                                                        children: "NVIDIA SXM5 H200"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/pricing#other",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowPricing(false);
                                                                        },
                                                                        children: "Network Shared Storage"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/pricing#other",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowPricing(false);
                                                                        },
                                                                        children: "Object Storage"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/pricing#other",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        onClick: ()=>{
                                                                            setShowPricing(false);
                                                                        },
                                                                        children: "Additional Public IP Address"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative",
                                            ref: datacenterRef,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "text-gray-600 text-sm font-medium hover:text-gray-900 flex items-center",
                                                    onClick: ()=>setShowDataCenter(!showDataCenter),
                                                    children: [
                                                        "Data Center",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showDataCenter ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                showDataCenter && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-[#F9F9F9] bg-opacity-90 absolute -left-8 py-6 mt-2 shadow-lg border-t border-gray-100 z-50 min-w-[280px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                            className: "space-y-2 text-sm",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                            href: "/data-center/iceland",
                                                                            className: "text-gray-600 hover:text-gray-900 flex items-center",
                                                                            children: [
                                                                                "Locations in planning",
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                    className: "w-4 h-4 ml-1",
                                                                                    fill: "none",
                                                                                    stroke: "currentColor",
                                                                                    viewBox: "0 0 24 24",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                        strokeLinecap: "round",
                                                                                        strokeLinejoin: "round",
                                                                                        strokeWidth: 2,
                                                                                        d: "M19 9l-7 7-7-7"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "pl-4 mt-2 space-y-2",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/data-center/iceland#iceland1",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>{
                                                                                            setShowDataCenter(false);
                                                                                        },
                                                                                        children: "Iceland 1"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                        href: "/data-center/iceland#iceland2",
                                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                                        onClick: ()=>{
                                                                                            setShowDataCenter(false);
                                                                                        },
                                                                                        children: "Iceland 2"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative",
                                            ref: resourcesRef,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "text-gray-600 text-sm font-medium hover:text-gray-900 flex items-center",
                                                    onClick: ()=>setShowResources(!showResources),
                                                    children: [
                                                        "Resources",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showResources ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                showResources && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-[#F9F9F9] bg-opacity-90 absolute -left-8 py-6 mt-2 shadow-lg border-t border-gray-100 z-50 min-w-[280px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                            className: "space-y-2 text-sm",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    href: "/cloud-api",
                                                                    className: "text-gray-600 hover:text-gray-900",
                                                                    children: "Manage Cloud Via API"
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "relative",
                                            ref: aboutRef,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "text-gray-600 text-sm font-medium hover:text-gray-900 flex items-center",
                                                    onClick: ()=>setShowAbout(!showAbout),
                                                    children: [
                                                        "About",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showAbout ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                showAbout && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-[#F9F9F9] bg-opacity-90 absolute -left-8 py-6 mt-2 shadow-lg border-t border-gray-100 z-50 min-w-[280px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                            className: "space-y-2 text-sm",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/about",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        children: "About US"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/about/careers",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        children: "Careers"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/about/newsroom",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        children: "Newsroom"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        href: "/blog",
                                                                        className: "text-gray-600 hover:text-gray-900",
                                                                        children: "Blog"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center space-x-4 ml-16",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            href: "https://cloud.canopywave.io/",
                                            className: "px-4 py-2 text-white bg-[#8CC63F] rounded hover:bg-[#7ab32f] transition-colors text-sm font-medium",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: "Canopy Wave Cloud"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            href: "/contact",
                                            className: "text-gray-600 hover:text-gray-900 text-sm font-medium",
                                            children: "Contact US"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "-mr-2 flex items-center md:hidden",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                type: "button",
                                className: "bg-gray-200 inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:bg-gray-300 focus:outline-none focus:bg-gray-300 transition duration-150 ease-in-out",
                                "aria-controls": "mobile-menu",
                                onClick: ()=>setIsOpen(!isOpen),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "sr-only",
                                        children: "Open main menu"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        className: "h-6 w-6",
                                        stroke: "currentColor",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: "2",
                                            d: "M4 6h16M4 12h16M4 18h16"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `md:hidden ${isOpen ? "" : "hidden"}`,
                id: "mobile-menu",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-2 pt-2 pb-3 sm:px-3",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: `flex items-center block w-full text-left text-gray-600 ${currentRouter === "home" ? "bg-gray-200" : ""} px-3 py-2 rounded-md text-base font-medium`,
                                    onClick: ()=>setShowMobileProducts(!showMobileProducts),
                                    children: [
                                        "Products",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileProducts ? "rotate-180" : ""}`,
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 9l-7 7-7-7"
                                            })
                                        })
                                    ]
                                }),
                                showMobileProducts && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "pl-4 mt-2 space-y-2 text-sm text-gray-600",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "flex items-center w-full text-left px-2 py-1 hover:bg-gray-100 rounded flex justify-between items-center",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setShowMobileSubMenu(showMobileSubMenu === "compute" ? null : "compute");
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Compute Services"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileSubMenu === "compute" ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: `pl-4 mt-2 space-y-2 ${showMobileSubMenu === "compute" ? "block" : "hidden"}`,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/compute-services#hgx-h200",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "NVIDIA HGX H200"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/compute-services#hgx-h100",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "NVIDIA HGX H100"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/compute-services#cpu-node",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "CPU Nodes"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/compute-services#bare-metal",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "Bare Metal GPU Cluster"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "w-full text-left px-2 py-1 hover:bg-gray-100 rounded flex justify-between items-center",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setShowMobileSubMenu(showMobileSubMenu === "storage" ? null : "storage");
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Storage Services"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileSubMenu === "storage" ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: `pl-4 mt-2 space-y-2 ${showMobileSubMenu === "storage" ? "block" : "hidden"}`,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/storage-services#local-storage",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "Local Storage"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/storage-services#shared-storage",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "Shared Storage"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/storage-services#object-storage",
                                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                children: "Object Storage"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "w-full text-left px-2 py-1 hover:bg-gray-100 rounded flex justify-between items-center",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setShowMobileSubMenu(showMobileSubMenu === "networking" ? null : "networking");
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Networking Services"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileSubMenu === "networking" ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                    className: `pl-4 mt-2 space-y-2 ${showMobileSubMenu === "networking" ? "block" : "hidden"}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                            href: "/networking-hardware",
                                                            children: "Networking Hardware Solution"
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "w-full text-left px-2 py-1 hover:bg-gray-100 rounded flex justify-between items-center",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setShowMobileSubMenu(showMobileSubMenu === "platform" ? null : "platform");
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Platform"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileSubMenu === "platform" ? "rotate-180" : ""}`,
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: 2,
                                                                d: "M19 9l-7 7-7-7"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: `pl-4 mt-2 space-y-2 ${showMobileSubMenu === "platform" ? "block" : "hidden"}`,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/platform#dcim-platform",
                                                                className: "text-gray-600 hover:text-gray-900",
                                                                children: "Canopy DCIM Platform"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                href: "/platform#cloud-platform",
                                                                className: "text-gray-600 hover:text-gray-900",
                                                                children: "Wave GPU cloud platform"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: `flex items-center block w-full text-left text-gray-600 hover:bg-gray-200 ${currentRouter === "solutions" ? "bg-gray-200" : ""} px-3 py-2 rounded-md text-base font-medium`,
                                    onClick: ()=>setShowMobileSolutions(!showMobileSolutions),
                                    children: [
                                        "Solutions",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileSolutions ? "rotate-180" : ""}`,
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 9l-7 7-7-7"
                                            })
                                        })
                                    ]
                                }),
                                showMobileSolutions && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "pl-4 mt-2 space-y-2 text-sm text-gray-600",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/model-training",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Model Training"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/inference",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Inference"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/rendering",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Rendering"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/private-cloud",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Private Cloud and GPUs Deployment"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/networking-hardware",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Networking Hardware Solution"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: `flex items-center block w-full text-left text-gray-600 hover:bg-gray-200 px-3 py-2 rounded-md text-base font-medium`,
                                    onClick: ()=>setShowMobilePricing(!showMobilePricing),
                                    children: [
                                        "Pricing",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobilePricing ? "rotate-180" : ""}`,
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 9l-7 7-7-7"
                                            })
                                        })
                                    ]
                                }),
                                showMobilePricing && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "pl-4 mt-2 space-y-2 text-sm text-gray-600 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/pricing#H100",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "NVIDIA SXM5 H100"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/pricing#H200",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "NVIDIA SXM5 H200"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/pricing#other",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Network Shared Storage"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/pricing#other",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Object Storage"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/pricing#other",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Additional Public IP Address"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: `flex items-center block w-full text-left text-gray-600 hover:bg-gray-200 px-3 py-2 rounded-md text-base font-medium`,
                                    onClick: ()=>setShowMobileDataCenter(!showMobileDataCenter),
                                    children: [
                                        "Data Center",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileDataCenter ? "rotate-180" : ""}`,
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 9l-7 7-7-7"
                                            })
                                        })
                                    ]
                                }),
                                showMobileDataCenter && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "space-y-2 text-sm",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        href: "/data-center/iceland",
                                                        className: "text-gray-600 hover:text-gray-900 flex items-center",
                                                        children: [
                                                            "Locations in planning",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                className: "w-4 h-4 ml-1",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M19 9l-7 7-7-7"
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                        className: "pl-4 mt-2 space-y-2",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    href: "/data-center/iceland#iceland1",
                                                                    className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                    onClick: ()=>{
                                                                        setShowMobileDataCenter(false);
                                                                        setIsOpen(false);
                                                                    },
                                                                    children: "Iceland 1"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    href: "/data-center/iceland#iceland2",
                                                                    className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                                    onClick: ()=>{
                                                                        setShowMobileDataCenter(false);
                                                                        setIsOpen(false);
                                                                    },
                                                                    children: "Iceland 2"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: `flex items-center block w-full text-left text-gray-600 hover:bg-gray-200 px-3 py-2 rounded-md text-base font-medium`,
                                    onClick: ()=>setShowMobileResources(!showMobileResources),
                                    children: [
                                        "Resources",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileResources ? "rotate-180" : ""}`,
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 9l-7 7-7-7"
                                            })
                                        })
                                    ]
                                }),
                                showMobileResources && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "pl-4 mt-2 space-y-2 text-sm text-gray-600",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            href: "/cloud-api",
                                            className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                            children: "Manage Cloud Via API"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: `flex items-center block w-full text-left text-gray-600 hover:bg-gray-200
              px-3 py-2 rounded-md text-base font-medium`,
                                    onClick: ()=>setShowMobileAbout(!showMobileAbout),
                                    children: [
                                        "About",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `w-4 h-4 ml-1 transform transition-transform duration-200 ${showMobileAbout ? "rotate-180" : ""}`,
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M19 9l-7 7-7-7"
                                            })
                                        })
                                    ]
                                }),
                                showMobileAbout && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "pl-4 mt-2 space-y-2 text-sm text-gray-600 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/about",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "About US"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/about/careers",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Careers"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/about/newsroom",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Newsroom"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_IwsLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                href: "/blog",
                                                className: "block px-2 py-1 hover:bg-gray-100 rounded",
                                                children: "Blog"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_6__/* .Button */ .z, {
                                className: "w-full sm:w-auto bg-[#8CC63F] hover:bg-[#7ab32f]",
                                onClick: ()=>window.open("https://cloud.canopywave.io/", "_blank", "noopener,noreferrer"),
                                children: "Canopy Wave Cloud"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative mt-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_6__/* .Button */ .z, {
                                variant: "outline",
                                className: "text-gray-600 hover:text-gray-900 w-full sm:w-auto",
                                onClick: ()=>window.location.href = "/contact",
                                children: "Contact US"
                            })
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4685:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4338);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6926);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6269);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _lib_utils__WEBPACK_IMPORTED_MODULE_4__]);
([_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _lib_utils__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__.cva)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , variant , size , asChild =false , ...props }, ref)=>{
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__.Slot : "button";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Comp, {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    });
});
Button.displayName = "Button";


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6269:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cn": () => (/* binding */ cn)
/* harmony export */ });
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6593);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8097);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__]);
([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_1__.twMerge)((0,clsx__WEBPACK_IMPORTED_MODULE_0__.clsx)(inputs));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ router)
/* harmony export */ });
const router = [
    {
        name: "home",
        path: "/"
    },
    {
        name: "about",
        path: "/about"
    }, 
];


/***/ })

};
;