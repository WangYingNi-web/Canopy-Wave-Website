"use strict";
exports.id = 598;
exports.ids = [598];
exports.modules = {

/***/ 9598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ useScrollToHash)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


const useScrollToHash = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const handleScroll = ()=>{
            const hash = window.location.hash;
            if (hash) {
                setTimeout(()=>{
                    const element = document.querySelector(hash);
                    if (element) {
                        const headerOffset = 100; // 头部导航的高度
                        const elementPosition = element.getBoundingClientRect().top;
                        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                        window.scrollTo({
                            top: offsetPosition,
                            behavior: "smooth"
                        });
                    }
                }, 200);
            }
        };
        handleScroll();
        window.addEventListener("load", handleScroll);
        router.events.on("hashChangeComplete", handleScroll);
        return ()=>{
            window.removeEventListener("load", handleScroll);
            router.events.off("hashChangeComplete", handleScroll);
        };
    }, [
        router.events
    ]);
};


/***/ })

};
;