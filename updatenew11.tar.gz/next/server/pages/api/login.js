"use strict";
(() => {
var exports = {};
exports.id = 994;
exports.ids = [994];
exports.modules = {

/***/ 1467:
/***/ ((module) => {

module.exports = import("@vercel/kv");;

/***/ }),

/***/ 7629:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _vercel_kv__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1467);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_vercel_kv__WEBPACK_IMPORTED_MODULE_0__]);
_vercel_kv__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function handler(req, res) {
    await _vercel_kv__WEBPACK_IMPORTED_MODULE_0__["default"].set("user_1_session", "session_token_value");
    const session = await _vercel_kv__WEBPACK_IMPORTED_MODULE_0__["default"].get("user_1_session");
    res.status(200).json(session);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7629));
module.exports = __webpack_exports__;

})();